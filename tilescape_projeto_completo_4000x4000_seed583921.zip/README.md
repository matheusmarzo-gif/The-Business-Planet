# TileScape 4K - Projeto Completo de Mapa Procedural

Este pacote contém todos os arquivos do projeto, o código-fonte completo (React + TypeScript + Vite) e o arquivo HTML autônomo com toda a lógica procedural de geração e renderização do mapa em Canvas.

---

## 🚀 Como Executar o Projeto

### Opção 1: Execução Imediata (Sem Instalar Nada)
Basta dar dois cliques no arquivo **`map_procedural_standalone.html`** ou **`index_standalone.html`** para abrir no seu navegador!
- Contém todo o algoritmo de ruído Perlin, Fractal Brownian Motion, renderizador de chunks, câmera interativa, minimapa e controles em tempo real em um único arquivo HTML.

### Opção 2: Projeto Completo (React + Vite)
Para rodar ou modificar o código-fonte com o servidor Vite local:
1. Instale as dependências:
   ```bash
   npm install
   ```
2. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
3. Abra o link exibido no terminal (geralmente `http://localhost:3000`).

---

## 📁 Estrutura de Arquivos no Pacote .ZIP

```
├── map_procedural_standalone.html  # HTML com toda a lógica procedural de construção do mapa
├── index_standalone.html           # Cópia direta para abertura rápida
├── map_overview.png                # Renderização panorâmica de alta resolução (2048x2048)
├── map_config.json                 # Metadados e coeficientes numéricos do mundo
├── tiles/                          # Pasta com todas as texturas de tiles PNG
│   ├── manifest.json               # Metadados de cada textura e cores
│   └── tile_*.png
├── src/                            # Código-fonte completo em TypeScript
│   ├── App.tsx                     # Componente principal da aplicação
│   ├── main.tsx                    # Ponto de entrada React
│   ├── index.css                   # Estilização Tailwind
│   ├── types/map.ts                # Definições de tipos e interfaces
│   ├── utils/                      # Algoritmos procedurais
│   │   ├── perlin.ts               # Algoritmo matemático de ruído Perlin 2D e fBm
│   │   ├── mapGenerator.ts         # Distribuição de biomas e elevação
│   │   └── tileAssets.ts           # Cache e carregamento de texturas
│   └── components/                 # Componentes de interface e Canvas
│       ├── MapCanvas.tsx           # Renderizador Canvas com LOD e culling
│       ├── Minimap.tsx             # Minimapa em tempo real
│       ├── ControlsPanel.tsx       # Painel de parâmetros e biomas
│       └── TileInspector.tsx       # HUD de inspeção e coordenadas
├── public/assets/aistudio/         # Texturas originais servidas pelo Vite
├── package.json                    # Dependências do projeto
├── tsconfig.json                   # Configurações TypeScript
└── vite.config.ts                  # Configuração do Vite
```

---

## ⚙️ Parâmetros do Mapa Gerado
- **Dimensões**: 4000 x 4000 tiles (16.000.000 blocos no total)
- **Semente (Seed)**: 583921
- **Escala de Frequência**: 0.008
- **Nível do Mar**: 46%
- **Oitavas Fractais**: 4
- **Preset de Terreno**: continents
- **Data da Exportação**: 03/11/2026, 17:33:34

## 🌿 Distribuição Atual de Biomas
- **Oceano Profundo**: 1.67%
- **Lago de Ninféias**: 1.67%
- **Água Costeira / Baixio**: 30.00%
- **Planície Verdejante**: 61.97%
- **Campo de Flores Amarelas**: 1.61%
- **Colina de Papoulas**: 1.83%
- **Clareira de Margaridas**: 1.25%
